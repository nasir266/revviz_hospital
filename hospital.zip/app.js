import express from 'express'
import path from 'path'
import { fileURLToPath } from "url";
import session from "express-session";
import dotenv from "dotenv";
import bodyParser from "body-parser";

import router from "./routes/authRoutes.js";

import {h_index, logiPage, MainPage} from "./controller/mainController.js";
import {
    addOrgForm,
    addOrgPage,
    addPlan,
    addPlanForm, assignPlanForm, AssignPlanPage, getActiveUsers,
    getAllPlans, getNewUsers, getUnActiveUsers
} from "./controller/organizationController.js";
import {getLogin, login, logout} from "./controller/authController.js";
import {addDiagnosisForm, addDiagnosisPage, getAllDiagnosis} from "./controller/diagnosisController.js";
import {addSymptomsForm, addSymptomsPage, getAllSymptoms} from "./controller/symptomsController.js";
import {setUserForViews} from './middleware/userMiddleWare.js';
import {upload} from "./middleware/upload.js";
import {isAuthenticated} from "./middleware/auth.js";
import {addDoctorForm, addDoctorPage, fetchDoctors} from "./controller/doctorsController.js";
import {setUserForSession} from "./middleware/session.js";
//import {session} from "express-session";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express()




// Middleware

app.use(express.json());
app.use(setUserForViews);
app.use(setUserForSession);
// ✅ Session middleware (MUST come before routes)
app.use(
    session({
        secret: "supersecretkey",
        resave: false,
        saveUninitialized: true,
        cookie: { secure: false },

    })
);

app.set('view engine', 'ejs');

app.use(express.urlencoded({extended:false}))

app.set("views", path.join(__dirname, "view"));

// Serve static files
app.use(express.static(path.join(__dirname, "public")));
/*app.use(express.static(publicPath))*/


//app.get('/', MainPage);

app.get("/",  isAuthenticated, MainPage);
app.get('/h_index', isAuthenticated, h_index)

//app.get('/login', logiPage)
app.get("/login",  getLogin);
app.post("/login", login);
app.get("/logout", logout);
/*logout*/

/*plans*/
app.get('/addPlan', isAuthenticated, addPlan)
app.post('/addPlanForm', isAuthenticated, addPlanForm)
app.get('/allPlans', isAuthenticated, getAllPlans)
app.get("/assignPlan", isAuthenticated, AssignPlanPage);
app.post("/assignPlanForm", isAuthenticated, assignPlanForm);

/*organization*/
app.get('/add_organization', isAuthenticated, addOrgPage)
app.post("/addOrgForm", upload.single("logo"), addOrgForm);
app.get("/allOrganization", isAuthenticated, getNewUsers);
app.get("/activeOrganization", isAuthenticated, getActiveUsers);
app.get("/unActiveOrganization", isAuthenticated, getUnActiveUsers);
//app.post('/addOrgForm', addOrgForm)

/*symptoms*/
app.get('/addSymptoms', isAuthenticated,  addSymptomsPage)
app.post('/addSymptoms', addSymptomsForm)
app.get('/allSymptoms', isAuthenticated, getAllSymptoms)

/*daignosis*/
app.get('/addDiagnosis', isAuthenticated, addDiagnosisPage)
app.get('/allDiagnosisPage', isAuthenticated, getAllDiagnosis)
app.post('/addDiagnosis', isAuthenticated, addDiagnosisForm)

/*doctors*/
app.get('/addDoctor', isAuthenticated, addDoctorPage);
app.post('/addDoctorForm',  addDoctorForm);
app.get('/allDoctors', isAuthenticated, fetchDoctors);


app.listen('3400')
