import db from "../config/db.js";

export const addSymptomsPage = (req, res) =>{
    res.render('symptoms',{user: req.session.user,message: null})

}

export const addSymptomsForm = (req, res) => {
    const { name } = req.body;

    const sql = "INSERT INTO symptoms (name) VALUES (?)";
    db.query(sql, [name], (err, result) => {
        if (err) {
            console.log(err);
            return res.render("symptoms", { user: req.session.user,message: "Error Inserting Data!" });
        }
        //res.status(200).json({ message: "User added successfully!", userId: result.insertId });
        return res.render("symptoms", { user: req.session.user,message: "added successfully!" });
    });
};

export const getAllSymptoms = (req, res) => {
    const sql = "SELECT * FROM symptoms";

    db.query(sql, (err, results) => {
        if (err) {
            console.error("Error fetching diagnosis:", err);
            return res.status(500).send("Error loading diagnosis");
        }

        // Ensure results is always an array
        res.render("allSymptoms", { user: req.session.user,diagnosisList: results || [] });
    });
};