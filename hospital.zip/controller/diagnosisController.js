import db from "../config/db.js";

export const addDiagnosisPage = (req, res) =>{
    res.render('diagnosis', { user: req.session.user, message: null })

}

export const addDiagnosisForm = (req, res) => {
    const { name } = req.body;

    const sql = "INSERT INTO diagnosis (name) VALUES (?)";
    db.query(sql, [name], (err, result) => {
        if (err) {
            console.log(err);
            return res.render("diagnosis", { user: req.session.user, message: "Error Inserting Data!" });
        }
        //res.status(200).json({ message: "User added successfully!", userId: result.insertId });
        return res.render("diagnosis", { user: req.session.user, message: "added successfully!" });
    });
};

export const getAllDiagnosis = (req, res) => {
    const sql = "SELECT * FROM diagnosis";

    db.query(sql, (err, results) => {
        if (err) {
            console.error("Error fetching diagnosis:", err);
            return res.status(500).send("Error loading diagnosis");
        }

        // Ensure results is always an array
        res.render("allDiagnosis", { user: req.session.user, diagnosisList: results || [] });
    });
};
