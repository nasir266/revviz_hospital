import db from "../config/db.js";
export function MainPage(req, res) {
    // 1️⃣ Dashboard counts
    const sqlCounts = `
        SELECT
            COUNT(*) AS total_users,
            SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) AS active_users,
            SUM(CASE WHEN status = 3 THEN 1 ELSE 0 END) AS inactive_users,
            SUM(CASE WHEN status = 0 THEN 1 ELSE 0 END) AS new_users
        FROM users
    `;

    // 2️⃣ Last 5 recently added users (status = 0)
    const sqlRecent = `
        SELECT *
        FROM users
        WHERE status = 0
        ORDER BY id DESC
            LIMIT 5
    `;

    // 3️⃣ Last 5 active users (status = 1)
    const sqlActive = `
        SELECT *
        FROM users
        WHERE status = 1
        ORDER BY id DESC
            LIMIT 5
    `;

    // 4️⃣ Last 5 plans
    const sqlLastPlans = `
        SELECT *
        FROM plans
        ORDER BY id DESC
            LIMIT 5
    `;

    // 5️⃣ Plans assigned per month
    const sqlPlansMonth = `
        SELECT MONTH(start_date) AS month, COUNT(*) AS total
        FROM user_plans
        WHERE YEAR(start_date) = YEAR(CURDATE())
        GROUP BY MONTH(start_date)
        ORDER BY MONTH(start_date)
    `;

    // Execute counts query first
    db.query(sqlCounts, (err, countResult) => {
        if (err) {
            console.error("Error fetching dashboard counts:", err);
            return res.render("a_index", {
                message: "Error loading data!",
                total_users: 0,
                new_users: 0,
                active_users: 0,
                inactive_users: 0,
                recentUsers: [],
                activeUsers: [],
                lastPlans: [],
                plansMonthly: Array(12).fill(0),
                user: req.session.user
            });
        }

        const counts = countResult[0];

        db.query(sqlRecent, (err2, recentUsers) => {
            if (err2) {
                console.error("Error fetching recent users:", err2);
                recentUsers = [];
            }

            db.query(sqlActive, (err3, activeUsers) => {
                if (err3) {
                    console.error("Error fetching active users:", err3);
                    activeUsers = [];
                }

                db.query(sqlLastPlans, (err4, lastPlans) => {
                    if (err4) {
                        console.error("Error fetching last plans:", err4);
                        lastPlans = [];
                    }

                    db.query(sqlPlansMonth, (err5, plansMonthData) => {
                        const plansMonthly = Array(12).fill(0);
                        if (!err5) {
                            plansMonthData.forEach(row => {
                                plansMonthly[row.month - 1] = row.total;
                            });
                        }

                        // Render dashboard
                        console.log(lastPlans);
                        console.log(plansMonthly);
                        res.render("a_index", {
                            total_users: counts.total_users,
                            new_users: counts.new_users,
                            active_users: counts.active_users,
                            inactive_users: counts.inactive_users,
                            recentUsers,
                            activeUsers,
                            lastPlans,
                            plansMonthly,
                            user: req.session.user,
                            message: null
                        });
                    });
                });
            });
        });
    });
}






export function h_index(req,res){
    res.render('index', {user: req.session.user, message: null})
}

export const logiPage = (req, res) =>{
    res.render('login')

}